import { json, runtimeEnv, seedDefaults } from "@/lib/admin-server";

type Row = Record<string, unknown>;
export async function GET() {
  try {
    const exists = await runtimeEnv.DB.prepare("SELECT key FROM site_content LIMIT 1").first(); if (!exists) await seedDefaults();
    const [content, items, places, media] = await runtimeEnv.DB.batch([
      runtimeEnv.DB.prepare("SELECT key, published_value FROM site_content ORDER BY sort_order"),
      runtimeEnv.DB.prepare("SELECT kind, data_json FROM content_items WHERE status = 'published' ORDER BY kind, sort_order"),
      runtimeEnv.DB.prepare("SELECT * FROM places WHERE status = 'published' ORDER BY featured DESC, sort_order, name"),
      runtimeEnv.DB.prepare("SELECT id, filename, content_type, size_bytes, caption, alt_text, status, created_at FROM media WHERE status = 'active' ORDER BY created_at DESC"),
    ]);
    const copy = Object.fromEntries(content.results.map((r: Row) => [String(r.key), String(r.published_value)]));
    const byKind = (kind: string) => items.results.filter((r: Row) => r.kind === kind).map((r: Row) => JSON.parse(String(r.data_json || "{}")));
    const publicPlaces = places.results.map((r: Row) => ({ id:r.id,name:r.name,type:r.type,barangay:r.barangay,googleMapsUrl:r.google_maps_url,googlePlaceId:r.google_place_id,sourceLatitude:r.source_latitude,sourceLongitude:r.source_longitude,displayLatitude:r.display_latitude,displayLongitude:r.display_longitude,address:r.address,phone:r.phone,website:r.website,description:r.description,bookingUrl:r.booking_url,coverMediaId:r.cover_media_id,photoIds:JSON.parse(String(r.photo_ids_json||"[]")),status:r.status,featured:Boolean(r.featured),verified:Boolean(r.verified),sortOrder:r.sort_order }));
    const publicMedia = media.results.map((r: Row) => ({ id:r.id,filename:r.filename,contentType:r.content_type,sizeBytes:r.size_bytes,caption:r.caption,altText:r.alt_text,status:r.status,createdAt:r.created_at,url:`/api/media/${r.id}`,downloadUrl:`/api/media/${r.id}?download=1` }));
    return json({ copy, communities: byKind("community"), categories: byKind("category"), opportunities: byKind("opportunity"), badges: byKind("badge"), places: publicPlaces, media: publicMedia }, 200, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300" });
  } catch (error) { return json({ error: error instanceof Error ? error.message : "Content unavailable" }, 500); }
}


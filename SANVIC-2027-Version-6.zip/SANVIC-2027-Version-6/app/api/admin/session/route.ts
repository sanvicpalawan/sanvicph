import { SESSION_COOKIE, json, requireAdmin, runtimeEnv, sha256 } from "@/lib/admin-server";

export async function GET(request: Request) {
  try { return json({ authenticated: await requireAdmin(request) }); }
  catch { return json({ authenticated: false }); }
}

export async function POST(request: Request) {
  try {
    const { pin } = await request.json() as { pin?: string };
    const supplied = await sha256(String(pin || ""));
    const expected = await sha256(runtimeEnv.ADMIN_PIN || "5309");
    if (supplied !== expected) return json({ error: "That passkey is not correct." }, 401);
    const token = `${crypto.randomUUID()}-${crypto.randomUUID()}`;
    const tokenHash = await sha256(token);
    const now = Date.now();
    const expires = now + 8 * 60 * 60 * 1000;
    await runtimeEnv.DB.batch([
      runtimeEnv.DB.prepare("DELETE FROM admin_sessions WHERE expires_at <= ?").bind(now),
      runtimeEnv.DB.prepare("INSERT INTO admin_sessions (id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?)").bind(crypto.randomUUID(), tokenHash, expires, now),
    ]);
    return json({ authenticated: true }, 200, { "Set-Cookie": `${SESSION_COOKIE}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800` });
  } catch { return json({ error: "Unable to sign in right now." }, 500); }
}

export async function DELETE(request: Request) {
  try {
    const cookie = request.headers.get("cookie") || "";
    const token = cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${SESSION_COOKIE}=`))?.slice(SESSION_COOKIE.length + 1) || "";
    if (token) await runtimeEnv.DB.prepare("DELETE FROM admin_sessions WHERE token_hash = ?").bind(await sha256(token)).run();
  } catch {}
  return json({ authenticated: false }, 200, { "Set-Cookie": `${SESSION_COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0` });
}


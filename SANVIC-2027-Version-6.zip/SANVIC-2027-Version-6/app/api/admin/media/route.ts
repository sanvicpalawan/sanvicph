import { audit, cleanText, json, requireAdmin, runtimeEnv } from "@/lib/admin-server";

export async function POST(request: Request) {
  try {
    if (!await requireAdmin(request)) return json({ error: "Unauthorized" }, 401);
    const form = await request.formData(); const file = form.get("file");
    if (!(file instanceof File)) return json({ error: "Choose an image or video." }, 400);
    if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) return json({ error: "Only image and video files are accepted." }, 400);
    if (file.size > 80 * 1024 * 1024) return json({ error: "Files must be 80 MB or smaller." }, 413);
    const id = crypto.randomUUID(); const extension = file.name.includes(".") ? file.name.split(".").pop()!.replace(/[^a-z0-9]/gi, "").toLowerCase() : "bin"; const objectKey = `media/${id}.${extension}`; const now = Date.now();
    await runtimeEnv.BUCKET.put(objectKey, file.stream(), { httpMetadata: { contentType: file.type }, customMetadata: { originalFilename: file.name } });
    await runtimeEnv.DB.batch([
      runtimeEnv.DB.prepare("INSERT INTO media (id, object_key, filename, content_type, size_bytes, caption, alt_text, status, created_at) VALUES (?, ?, ?, ?, ?, '', '', 'active', ?)").bind(id, objectKey, cleanText(file.name, 240), file.type, file.size, now),
      audit("upload", "media", id, `Uploaded ${cleanText(file.name, 180)}`),
    ]);
    return json({ media: { id, filename: file.name, contentType: file.type, sizeBytes: file.size, caption: "", altText: "", status: "active", createdAt: now, url: `/api/media/${id}`, downloadUrl: `/api/media/${id}?download=1` } }, 201);
  } catch (error) { return json({ error: error instanceof Error ? error.message : "Upload failed." }, 500); }
}


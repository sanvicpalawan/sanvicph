import { audit, cleanText, json, requireAdmin, runtimeEnv, seedDefaults } from "@/lib/admin-server";

type Row = Record<string, unknown>;
const contentRow = (r: Row) => ({ key: r.key, section: r.section, label: r.label, draftValue: r.draft_value, publishedValue: r.published_value, sortOrder: r.sort_order, updatedAt: r.updated_at });
const itemRow = (r: Row) => ({ id: r.id, kind: r.kind, slug: r.slug, title: r.title, data: JSON.parse(String(r.data_json || "{}")), status: r.status, sortOrder: r.sort_order, createdAt: r.created_at, updatedAt: r.updated_at });
const mediaRow = (r: Row) => ({ id: r.id, filename: r.filename, contentType: r.content_type, sizeBytes: r.size_bytes, caption: r.caption, altText: r.alt_text, status: r.status, createdAt: r.created_at, url: `/api/media/${r.id}`, downloadUrl: `/api/media/${r.id}?download=1` });
const placeRow = (r: Row) => ({ id: r.id, name: r.name, type: r.type, barangay: r.barangay, googleMapsUrl: r.google_maps_url, googlePlaceId: r.google_place_id, sourceLatitude: r.source_latitude, sourceLongitude: r.source_longitude, displayLatitude: r.display_latitude, displayLongitude: r.display_longitude, address: r.address, phone: r.phone, website: r.website, description: r.description, bookingUrl: r.booking_url, coverMediaId: r.cover_media_id, photoIds: JSON.parse(String(r.photo_ids_json || "[]")), status: r.status, featured: Boolean(r.featured), verified: Boolean(r.verified), sortOrder: r.sort_order, createdAt: r.created_at, updatedAt: r.updated_at });

export async function GET(request: Request) {
  try {
    if (!await requireAdmin(request)) return json({ error: "Unauthorized" }, 401);
    await seedDefaults();
    const [content, items, places, media, log] = await runtimeEnv.DB.batch([
      runtimeEnv.DB.prepare("SELECT * FROM site_content ORDER BY section, sort_order, key"),
      runtimeEnv.DB.prepare("SELECT * FROM content_items ORDER BY kind, sort_order, title"),
      runtimeEnv.DB.prepare("SELECT * FROM places ORDER BY CASE status WHEN 'published' THEN 0 WHEN 'draft' THEN 1 ELSE 2 END, sort_order, name"),
      runtimeEnv.DB.prepare("SELECT * FROM media ORDER BY created_at DESC LIMIT 200"),
      runtimeEnv.DB.prepare("SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 50"),
    ]);
    return json({ content: content.results.map(contentRow), items: items.results.map(itemRow), places: places.results.map(placeRow), media: media.results.map(mediaRow), audit: log.results });
  } catch (error) { return json({ error: error instanceof Error ? error.message : "Unable to load admin data." }, 500); }
}

export async function PUT(request: Request) {
  try {
    if (!await requireAdmin(request)) return json({ error: "Unauthorized" }, 401);
    const payload = await request.json() as { resource?: string; record?: Record<string, unknown>; publish?: boolean };
    const record = payload.record || {}; const now = Date.now();
    if (payload.resource === "content") {
      const key = cleanText(record.key, 120); const section = cleanText(record.section, 80); const label = cleanText(record.label, 120); const value = cleanText(record.draftValue);
      if (!key || !section || !label) return json({ error: "Content key, section, and label are required." }, 400);
      const published = payload.publish ? value : cleanText(record.publishedValue);
      await runtimeEnv.DB.batch([
        runtimeEnv.DB.prepare("INSERT INTO site_content (key, section, label, draft_value, published_value, sort_order, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(key) DO UPDATE SET section=excluded.section, label=excluded.label, draft_value=excluded.draft_value, published_value=excluded.published_value, sort_order=excluded.sort_order, updated_at=excluded.updated_at").bind(key, section, label, value, published, Number(record.sortOrder) || 0, now),
        audit(payload.publish ? "publish" : "save", "content", key, `${payload.publish ? "Published" : "Saved"} ${label}`),
      ]);
      return json({ ok: true });
    }
    if (payload.resource === "item") {
      const id = cleanText(record.id, 120) || crypto.randomUUID(); const kind = cleanText(record.kind, 40); const slug = cleanText(record.slug, 120).toLowerCase().replace(/[^a-z0-9-]+/g, "-"); const title = cleanText(record.title, 160);
      if (!kind || !slug || !title) return json({ error: "Type, slug, and title are required." }, 400);
      const status = payload.publish ? "published" : cleanText(record.status, 20) || "draft";
      const dataObject = record.data && typeof record.data === "object" ? { ...(record.data as Record<string, unknown>) } : {};
      dataObject.id = slug; if (kind === "community" || kind === "badge") dataObject.name = title; else dataObject.title = title;
      const data = JSON.stringify(dataObject);
      await runtimeEnv.DB.batch([
        runtimeEnv.DB.prepare("INSERT INTO content_items (id, kind, slug, title, data_json, status, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET kind=excluded.kind, slug=excluded.slug, title=excluded.title, data_json=excluded.data_json, status=excluded.status, sort_order=excluded.sort_order, updated_at=excluded.updated_at").bind(id, kind, slug, title, data, status, Number(record.sortOrder) || 0, now, now),
        audit(payload.publish ? "publish" : "save", kind, id, `${payload.publish ? "Published" : "Saved"} ${title}`),
      ]);
      return json({ ok: true, id });
    }
    if (payload.resource === "place") {
      const id = cleanText(record.id, 120) || crypto.randomUUID(); const name = cleanText(record.name, 180); const barangay = cleanText(record.barangay, 80); const type = cleanText(record.type, 80);
      const lat = Number(record.displayLatitude); const lng = Number(record.displayLongitude);
      if (!name || !barangay || !type || !Number.isFinite(lat) || !Number.isFinite(lng)) return json({ error: "Name, type, barangay, latitude, and longitude are required." }, 400);
      const status = payload.publish ? "published" : cleanText(record.status, 20) || "draft";
      await runtimeEnv.DB.batch([
        runtimeEnv.DB.prepare("INSERT INTO places (id, name, type, barangay, google_maps_url, google_place_id, source_latitude, source_longitude, display_latitude, display_longitude, address, phone, website, description, booking_url, cover_media_id, photo_ids_json, status, featured, verified, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET name=excluded.name, type=excluded.type, barangay=excluded.barangay, google_maps_url=excluded.google_maps_url, google_place_id=excluded.google_place_id, source_latitude=excluded.source_latitude, source_longitude=excluded.source_longitude, display_latitude=excluded.display_latitude, display_longitude=excluded.display_longitude, address=excluded.address, phone=excluded.phone, website=excluded.website, description=excluded.description, booking_url=excluded.booking_url, cover_media_id=excluded.cover_media_id, photo_ids_json=excluded.photo_ids_json, status=excluded.status, featured=excluded.featured, verified=excluded.verified, sort_order=excluded.sort_order, updated_at=excluded.updated_at").bind(id, name, type, barangay, cleanText(record.googleMapsUrl, 2000), cleanText(record.googlePlaceId, 300), record.sourceLatitude == null ? null : Number(record.sourceLatitude), record.sourceLongitude == null ? null : Number(record.sourceLongitude), lat, lng, cleanText(record.address, 1000), cleanText(record.phone, 80), cleanText(record.website, 1000), cleanText(record.description), cleanText(record.bookingUrl, 1000), cleanText(record.coverMediaId, 120), JSON.stringify(Array.isArray(record.photoIds) ? record.photoIds : []), status, record.featured ? 1 : 0, record.verified ? 1 : 0, Number(record.sortOrder) || 0, now, now),
        audit(payload.publish ? "publish" : "save", "place", id, `${payload.publish ? "Published" : "Saved"} ${name} in ${barangay}`),
      ]);
      return json({ ok: true, id });
    }
    if (payload.resource === "media") {
      const id = cleanText(record.id, 120); if (!id) return json({ error: "Media id is required." }, 400);
      await runtimeEnv.DB.batch([
        runtimeEnv.DB.prepare("UPDATE media SET caption = ?, alt_text = ? WHERE id = ?").bind(cleanText(record.caption, 500), cleanText(record.altText, 500), id),
        audit("edit", "media", id, `Updated ${cleanText(record.filename, 160) || "media"}`),
      ]);
      return json({ ok: true });
    }
    return json({ error: "Unknown resource." }, 400);
  } catch (error) { return json({ error: error instanceof Error ? error.message : "Unable to save." }, 500); }
}

export async function DELETE(request: Request) {
  try {
    if (!await requireAdmin(request)) return json({ error: "Unauthorized" }, 401);
    const { resource, id } = await request.json() as { resource?: string; id?: string };
    const safeId = cleanText(id, 120); if (!safeId) return json({ error: "Id is required." }, 400);
    const table = resource === "place" ? "places" : resource === "item" ? "content_items" : resource === "media" ? "media" : "";
    if (!table) return json({ error: "Unknown resource." }, 400);
    await runtimeEnv.DB.batch([
      runtimeEnv.DB.prepare(`UPDATE ${table} SET status = 'archived' WHERE id = ?`).bind(safeId),
      audit("archive", resource || "record", safeId, "Archived from admin"),
    ]);
    return json({ ok: true });
  } catch (error) { return json({ error: error instanceof Error ? error.message : "Unable to archive." }, 500); }
}

import { runtimeEnv } from "@/lib/admin-server";

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;
    const row = await runtimeEnv.DB.prepare("SELECT object_key, filename, content_type, status FROM media WHERE id = ? LIMIT 1").bind(id).first<Record<string, string>>();
    if (!row || row.status === "archived") return new Response("Not found", { status: 404 });
    const object = await runtimeEnv.BUCKET.get(row.object_key); if (!object) return new Response("Not found", { status: 404 });
    const headers = new Headers(); object.writeHttpMetadata(headers); headers.set("ETag", object.httpEtag); headers.set("Cache-Control", "public, max-age=3600"); headers.set("X-Content-Type-Options", "nosniff");
    if (new URL(request.url).searchParams.get("download") === "1") headers.set("Content-Disposition", `attachment; filename="${row.filename.replace(/["\r\n]/g, "_")}"`);
    return new Response(object.body, { headers });
  } catch { return new Response("Media unavailable", { status: 500 }); }
}


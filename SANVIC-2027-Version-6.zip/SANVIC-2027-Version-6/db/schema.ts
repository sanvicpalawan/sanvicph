import { index, integer, real, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const adminSessions = sqliteTable("admin_sessions", {
  id: text("id").primaryKey(),
  tokenHash: text("token_hash").notNull(),
  expiresAt: integer("expires_at").notNull(),
  createdAt: integer("created_at").notNull(),
}, (table) => [uniqueIndex("admin_sessions_token_hash_idx").on(table.tokenHash), index("admin_sessions_expires_at_idx").on(table.expiresAt)]);

export const siteContent = sqliteTable("site_content", {
  key: text("key").primaryKey(),
  section: text("section").notNull(),
  label: text("label").notNull(),
  draftValue: text("draft_value").notNull(),
  publishedValue: text("published_value").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
  updatedAt: integer("updated_at").notNull(),
}, (table) => [index("site_content_section_idx").on(table.section, table.sortOrder)]);

export const contentItems = sqliteTable("content_items", {
  id: text("id").primaryKey(),
  kind: text("kind").notNull(),
  slug: text("slug").notNull(),
  title: text("title").notNull(),
  dataJson: text("data_json").notNull(),
  status: text("status").notNull().default("published"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull(),
}, (table) => [uniqueIndex("content_items_kind_slug_idx").on(table.kind, table.slug), index("content_items_kind_status_idx").on(table.kind, table.status, table.sortOrder)]);

export const media = sqliteTable("media", {
  id: text("id").primaryKey(),
  objectKey: text("object_key").notNull(),
  filename: text("filename").notNull(),
  contentType: text("content_type").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  caption: text("caption").notNull().default(""),
  altText: text("alt_text").notNull().default(""),
  status: text("status").notNull().default("active"),
  createdAt: integer("created_at").notNull(),
}, (table) => [uniqueIndex("media_object_key_idx").on(table.objectKey), index("media_status_created_idx").on(table.status, table.createdAt)]);

export const places = sqliteTable("places", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  barangay: text("barangay").notNull(),
  googleMapsUrl: text("google_maps_url").notNull().default(""),
  googlePlaceId: text("google_place_id").notNull().default(""),
  sourceLatitude: real("source_latitude"),
  sourceLongitude: real("source_longitude"),
  displayLatitude: real("display_latitude").notNull(),
  displayLongitude: real("display_longitude").notNull(),
  address: text("address").notNull().default(""),
  phone: text("phone").notNull().default(""),
  website: text("website").notNull().default(""),
  description: text("description").notNull().default(""),
  bookingUrl: text("booking_url").notNull().default(""),
  coverMediaId: text("cover_media_id").notNull().default(""),
  photoIdsJson: text("photo_ids_json").notNull().default("[]"),
  status: text("status").notNull().default("published"),
  featured: integer("featured", { mode: "boolean" }).notNull().default(false),
  verified: integer("verified", { mode: "boolean" }).notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull(),
}, (table) => [index("places_barangay_status_idx").on(table.barangay, table.status, table.sortOrder), index("places_type_status_idx").on(table.type, table.status, table.sortOrder)]);

export const auditLog = sqliteTable("audit_log", {
  id: text("id").primaryKey(),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  summary: text("summary").notNull(),
  createdAt: integer("created_at").notNull(),
}, (table) => [index("audit_log_created_idx").on(table.createdAt)]);

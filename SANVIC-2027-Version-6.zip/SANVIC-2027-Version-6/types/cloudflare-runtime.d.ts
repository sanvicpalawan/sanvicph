declare module "cloudflare:workers" { export const env: Record<string, any>; }
interface D1Result<T = Record<string, unknown>> { results: T[]; success: boolean; meta: Record<string, unknown>; }
interface D1PreparedStatement { bind(...values: unknown[]): D1PreparedStatement; first<T = Record<string, unknown>>(): Promise<T | null>; run(): Promise<D1Result>; all<T = Record<string, unknown>>(): Promise<D1Result<T>>; }
interface D1Database { prepare(query: string): D1PreparedStatement; batch<T = Record<string, unknown>>(statements: D1PreparedStatement[]): Promise<D1Result<T>[]>; }
interface R2ObjectBody { body: ReadableStream; httpEtag: string; writeHttpMetadata(headers: Headers): void; }
interface R2Bucket { put(key: string, value: ReadableStream | ArrayBuffer | Blob, options?: Record<string, unknown>): Promise<unknown>; get(key: string): Promise<R2ObjectBody | null>; delete(key: string): Promise<void>; }
interface Fetcher { fetch(request: Request): Promise<Response>; }

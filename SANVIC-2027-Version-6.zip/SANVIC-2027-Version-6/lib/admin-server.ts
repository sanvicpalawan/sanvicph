import { env } from "cloudflare:workers";
import { baiaSeed, copySeed, itemSeed } from "./admin-seed";

export type RuntimeEnv = { DB: D1Database; BUCKET: R2Bucket; ADMIN_PIN?: string; GOOGLE_MAPS_API_KEY?: string };
export const runtimeEnv = env as unknown as RuntimeEnv;
export const SESSION_COOKIE = "sanvic_admin";

export function json(data: unknown, status = 200, headers?: HeadersInit) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store", ...headers } });
}

export function cookieValue(request: Request, name: string) {
  const cookie = request.headers.get("cookie") || "";
  return cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${name}=`))?.slice(name.length + 1) || "";
}

export async function sha256(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function requireAdmin(request: Request) {
  const token = cookieValue(request, SESSION_COOKIE);
  if (!token) return false;
  const tokenHash = await sha256(token);
  const row = await runtimeEnv.DB.prepare("SELECT id FROM admin_sessions WHERE token_hash = ? AND expires_at > ? LIMIT 1").bind(tokenHash, Date.now()).first();
  return Boolean(row);
}

export async function seedDefaults() {
  const now = Date.now();
  const statements: D1PreparedStatement[] = [];
  for (const [key, section, label, value] of copySeed) {
    statements.push(runtimeEnv.DB.prepare("INSERT OR IGNORE INTO site_content (key, section, label, draft_value, published_value, sort_order, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)").bind(key, section, label, value, value, statements.length, now));
  }
  for (const item of itemSeed) {
    statements.push(runtimeEnv.DB.prepare("INSERT OR IGNORE INTO content_items (id, kind, slug, title, data_json, status, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'published', ?, ?, ?)").bind(item.id, item.kind, item.slug, item.title, JSON.stringify(item.data), item.sortOrder, now, now));
  }
  statements.push(runtimeEnv.DB.prepare("INSERT OR IGNORE INTO places (id, name, type, barangay, google_maps_url, google_place_id, source_latitude, source_longitude, display_latitude, display_longitude, address, phone, website, description, booking_url, cover_media_id, photo_ids_json, status, featured, verified, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").bind(
    baiaSeed.id, baiaSeed.name, baiaSeed.type, baiaSeed.barangay, baiaSeed.googleMapsUrl, baiaSeed.googlePlaceId, baiaSeed.sourceLatitude, baiaSeed.sourceLongitude, baiaSeed.displayLatitude, baiaSeed.displayLongitude, baiaSeed.address, baiaSeed.phone, baiaSeed.website, baiaSeed.description, baiaSeed.bookingUrl, baiaSeed.coverMediaId, JSON.stringify(baiaSeed.photoIds), baiaSeed.status, 1, 1, 0, now, now,
  ));
  for (let index = 0; index < statements.length; index += 40) await runtimeEnv.DB.batch(statements.slice(index, index + 40));
}

export function audit(action: string, entityType: string, entityId: string, summary: string) {
  return runtimeEnv.DB.prepare("INSERT INTO audit_log (id, action, entity_type, entity_id, summary, created_at) VALUES (?, ?, ?, ?, ?, ?)").bind(crypto.randomUUID(), action, entityType, entityId, summary, Date.now());
}

export function cleanText(value: unknown, max = 5000) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

